# Caixa de e-mail do Forentis — Parte 1 (envio, assinatura e registro)

Caixa única de solicitações na hospedagem `mail.damadvogados.com.br`, com envio pela porta 587 e IMAP na 993.
A pasta de enviados do servidor é `INBOX.Sent` (conferido em 13/11/2026).

## O que esta parte faz

- **Envio pelo Forentis** com a assinatura de quem conferiu: nome e cargo do funcionário, mais os dados do escritório e o logo.
- **Registro de cada envio** em `.dados/emails.json`. Cada pedido vira uma *conversa*, com código no assunto (`[DAM-4F7K2Q]`), destinatários, texto, anexos, quem enviou e quando.
- **Cópia na pasta Enviados** da caixa, para o e-mail aparecer no webmail/Outlook igual a um enviado à mão.
- **Lembrete na mesma conversa**: sai com "Re:" e os cabeçalhos de resposta, então a empresa recebe no mesmo fio. Trava: no máximo 3 envios por conversa, com `DIAS_SEM_REPETIR` dias entre eles.
- **Modo teste** (`MODO_TESTE=true`): tudo vai para o `EMAIL_TESTE`. O assunto leva `[TESTE]` e o corpo começa avisando para onde o e-mail iria.
- **Solicitação à empresa** (`envio-empresa.service.ts`) passa a enviar pela caixa: ganha assinatura, registro e código, e o código entra no comentário da tarefa.

## Instalação

1. Instale a biblioteca IMAP:
   ```
   npm i imapflow
   ```
2. Copie os arquivos do pacote para as mesmas pastas do projeto.
   - **Novos:** `config/email.config.ts`, `models/email.model.ts`, `models/assinatura-email.model.ts`, `repositories/email.repository.ts`, `repositories/assinatura-email.repository.ts`, `integrations/imap.integration.ts`, `service/caixa-email.service.ts`, `service/assinatura-email.service.ts`, `validators/email.validator.ts`, `validators/assinatura-email.validator.ts`, `controllers/email.controller.ts`, `controllers/assinatura-email.controller.ts` e as rotas em `app/api/emails/`.
   - **Substituídos:** `config/env.config.ts` (só ganhou o bloco `caixaEmail`), `integrations/email.integration.ts` (o `enviarEmail` antigo continua funcionando), `service/envio-empresa.service.ts` e `.env.example`.
3. Crie a conta `documentos@damadvogados.com.br` no painel da hospedagem (ou use outra e ajuste o `.env`).
4. Preencha no `.env` (modelo no `.env.example`):
   ```
   SMTP_HOST=mail.damadvogados.com.br
   SMTP_PORT=587
   SMTP_USER=documentos@damadvogados.com.br
   SMTP_PASS=********
   SMTP_FROM="DAM Advogados - Solicitações" <documentos@damadvogados.com.br>
   IMAP_PORT=993
   IMAP_PASTA_ENVIADOS=INBOX.Sent
   EMAIL_TESTE=seu-email@damadvogados.com.br
   ```
5. Coloque o logo em `public/email/logo-dam.png` (PNG, uns 220 px de largura). Sem o arquivo, a assinatura sai só com texto.
6. Complete endereço, telefone e site do escritório em `src/config/email.config.ts`. Linhas vazias não aparecem.

## Testar

Se houver `API_KEY` no `.env`, mande o cabeçalho `x-api-key` em todas as chamadas.

1. **Conexão** (não envia nada): `GET /api/emails/testar-conexao`. O retorno precisa ter `smtp.ok`, `imap.ok` e `pastaEnviados.existe` todos `true`.
2. **Assinatura do funcionário**: `POST /api/emails/assinaturas`
   ```json
   { "nome": "Matheus Farias", "cargo": "Setor de Revisão", "telefone": "(49) 0000-0000" }
   ```
   Para conferir no navegador, abra `GET /api/emails/assinaturas/{id}/previa`, ou `/api/emails/assinaturas/padrao/previa` para quem não tem cadastro. Com `API_KEY` definida o navegador não manda o cabeçalho; teste a prévia sem a chave.
3. **Envio avulso** (modo teste ligado): `POST /api/emails`
   ```json
   {
     "para": ["rh@empresa.com.br"],
     "assunto": "Solicitação de PPP",
     "texto": "Prezados,\n\nSolicitamos o PPP de ...",
     "funcionario": "Matheus Farias",
     "vinculo": { "tipo": "avulso", "tarefaId": 12345 }
   }
   ```
   Responde 201 quando o e-mail saiu e 502 quando não saiu (a conversa fica registrada com o motivo). Com `tarefaId`, também comenta na tarefa do Lawyertool.
4. **Lembrete**: `POST /api/emails` com `{ "conversaId": "...", "texto": "Reiteramos o pedido...", "funcionario": "Matheus Farias" }`.
5. **Consulta**: `GET /api/emails?status=enviado&busca=DAM-` e `GET /api/emails/{id}`.

## Regras

- A assinatura é escolhida pelo nome do funcionário que conferiu, sem diferença de acento ou maiúscula. Sem cadastro, sai o nome dele com os dados do escritório.
- Uma solicitação com e-mail já enviado não envia de novo (409). A cobrança vai como lembrete na conversa.
- Se o envio falhar, a conversa fica com `status: "falhou"` e o próximo envio da mesma solicitação reaproveita a conversa.
- Se a cópia nos Enviados falhar, o e-mail já saiu e o envio não é desfeito. A mensagem fica com `copiadaEnviados: false`.
- Anexos somados até `EMAIL_MAX_ANEXOS_MB` (padrão 15 MB).

## Próximas partes

- **Parte 2 — respostas e monitoramento:** leitura da caixa pelo IMAP de tempos em tempos. Cada resposta é ligada à conversa (In-Reply-To, References ou código no assunto), e devoluções (endereço inválido, caixa cheia) são marcadas. Anexos recebidos ficam guardados para conferência e para anexar na tarefa. Conversas sem resposta há N dias são listadas.
- **Parte 3 — tela "E-mails" no Forentis:** caixa de conversas, histórico, lembrete com um clique, cadastro de assinaturas e indicadores.
