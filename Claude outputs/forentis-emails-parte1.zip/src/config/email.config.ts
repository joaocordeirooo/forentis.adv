// Regras fixas da caixa de e-mail do Forentis (o que vem do .env fica em env.config.ts).

// Dados do escritório que entram em toda assinatura. Linha vazia não aparece.
export const ESCRITORIO_ASSINATURA = {
  nome: 'Darcísio Müller Advogados Associados',
  endereco: '', // ex.: 'Rua ..., nº ... — Centro'
  cidade: 'Fraiburgo/SC',
  telefone: '', // ex.: '(49) 3246-0000'
  site: '', // ex.: 'www.damadvogados.com.br'
  corPrincipal: '#1f3a5f',
  // Logo da assinatura (opcional). Se o arquivo não existir, a assinatura sai sem logo.
  logo: 'public/email/logo-dam.png',
};

// Id da assinatura usada quando o funcionário não tem uma cadastrada.
export const ASSINATURA_PADRAO_ID = 'padrao';

// Código que vai no assunto ("[DAM-4F7K2Q]"). Ajuda a ligar a resposta ao envio (parte 2).
export const PREFIXO_CODIGO_EMAIL = 'DAM';

// Lembretes na mesma conversa: no máximo N envios, com X dias de intervalo.
export const MAX_ENVIOS_POR_CONVERSA = 3;
