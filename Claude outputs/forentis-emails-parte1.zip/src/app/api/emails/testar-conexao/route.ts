import { testarConexao } from '@/controllers/email.controller';
import { tratarErros } from '@/middlewares/tratar-erros.middleware';
import { exigirChaveApi } from '@/middlewares/chave-api.middleware';

export const runtime = 'nodejs';

export const GET = tratarErros(exigirChaveApi(testarConexao));
