import { ImapFlow } from 'imapflow';
import { config } from '@/config/env.config';
import { AppError } from '@/errors/app.errors';

// Abre uma conexão IMAP com a caixa do Forentis, executa a operação e fecha.
export async function comImap<T>(operacao: (cliente: ImapFlow) => Promise<T>): Promise<T> {
  const caixa = config.caixaEmail;
  const cliente = new ImapFlow({
    host: caixa.imapHost,
    port: caixa.imapPorta,
    secure: caixa.imapPorta === 993,
    auth: { user: caixa.usuario, pass: caixa.senha },
    logger: false, // o log do imapflow é muito verboso
  });

  try {
    await cliente.connect();
  } catch (erro) {
    throw new AppError(`Não conectou ao IMAP (${caixa.imapHost}:${caixa.imapPorta}): ${(erro as Error).message}`, 502);
  }

  try {
    return await operacao(cliente);
  } finally {
    await cliente.logout().catch(() => undefined);
  }
}

// Guarda a mensagem já montada na pasta Enviados, marcada como lida.
export async function copiarParaEnviados(mensagemBruta: Buffer): Promise<void> {
  const pasta = config.caixaEmail.pastaEnviados;
  await comImap(async (cliente) => {
    const resultado = await cliente.append(pasta, mensagemBruta, ['\\Seen']);
    if (!resultado) throw new Error(`o servidor recusou a gravação na pasta ${pasta}`);
  });
}

export async function listarPastas(): Promise<string[]> {
  return comImap(async (cliente) => (await cliente.list()).map((p) => p.path));
}
