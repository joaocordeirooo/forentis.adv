import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import type { z } from 'zod';
import { config } from '@/config/env.config';
import { ASSINATURA_PADRAO_ID, ESCRITORIO_ASSINATURA as ESC } from '@/config/email.config';
import { AppError } from '@/errors/app.errors';
import type { AssinaturaEmail } from '@/models/assinatura-email.model';
import * as repositorio from '@/repositories/assinatura-email.repository';
import type { criarAssinaturaSchema, editarAssinaturaSchema } from '@/validators/assinatura-email.validator';

type DadosCriar = z.infer<typeof criarAssinaturaSchema>;
type DadosEditar = z.infer<typeof editarAssinaturaSchema>;

const CID_LOGO = 'logo-dam';

export function escaparHtml(texto: string): string {
  return texto.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const normalizar = (texto: string) =>
  texto.normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase().replace(/\s+/g, ' ');

export function listar() {
  return repositorio.listarAssinaturas();
}

export async function obter(id: string): Promise<AssinaturaEmail> {
  if (id === ASSINATURA_PADRAO_ID) return assinaturaPadrao('Equipe DAM Advogados');
  const assinatura = await repositorio.obterAssinatura(id);
  if (!assinatura) throw new AppError('Assinatura não encontrada.', 404);
  return assinatura;
}

export async function criar(dados: DadosCriar): Promise<AssinaturaEmail> {
  const existentes = await repositorio.listarAssinaturas();
  if (existentes.some((a) => normalizar(a.nome) === normalizar(dados.nome))) {
    throw new AppError(`Já existe assinatura para "${dados.nome}".`, 409);
  }
  const agora = new Date().toISOString();
  return repositorio.salvarAssinatura({ id: randomUUID(), ...dados, criadaEm: agora, atualizadaEm: agora });
}

export async function editar(id: string, dados: DadosEditar): Promise<AssinaturaEmail> {
  const atual = await obter(id);
  if (id === ASSINATURA_PADRAO_ID) throw new AppError('A assinatura padrão vem de email.config.ts.', 400);
  return repositorio.salvarAssinatura({ ...atual, ...dados, atualizadaEm: new Date().toISOString() });
}

export async function excluir(id: string): Promise<void> {
  if (!(await repositorio.removerAssinatura(id))) throw new AppError('Assinatura não encontrada.', 404);
}

function assinaturaPadrao(nome: string): AssinaturaEmail {
  const agora = new Date().toISOString();
  return {
    id: ASSINATURA_PADRAO_ID,
    nome,
    cargo: null,
    oab: null,
    telefone: null,
    whatsapp: null,
    email: null,
    ativa: true,
    criadaEm: agora,
    atualizadaEm: agora,
  };
}

// Acha a assinatura do funcionário pelo nome (sem diferença de acento/maiúscula).
// Sem cadastro, a assinatura sai só com o nome dele e os dados do escritório.
export async function resolverAssinatura(funcionario: string): Promise<AssinaturaEmail> {
  const nome = funcionario.trim();
  const achada = (await repositorio.listarAssinaturas()).find((a) => a.ativa && normalizar(a.nome) === normalizar(nome));
  return achada ?? assinaturaPadrao(nome || 'Equipe DAM Advogados');
}

async function lerLogo(): Promise<Buffer | null> {
  if (!ESC.logo) return null;
  try {
    return await readFile(path.join(/*turbopackIgnore: true*/ process.cwd(), ESC.logo));
  } catch {
    return null; // sem logo: a assinatura sai só com texto
  }
}

export interface AssinaturaMontada {
  html: string;
  texto: string;
  logo: { nome: string; conteudo: Buffer; mimeType: string; cid: string } | null;
}

// Monta a assinatura em HTML (tabela com estilos inline: é o que funciona no Outlook/Gmail) e em texto puro.
// srcLogo: na prévia do navegador o logo vai como data: URL; no e-mail, como anexo "cid".
export async function montarAssinatura(a: AssinaturaEmail, srcLogo?: 'data-url'): Promise<AssinaturaMontada> {
  const logo = await lerLogo();
  const emailContato = a.email ?? config.smtp.usuario;
  const juntar = (partes: (string | null | undefined)[], separador: string) => partes.filter(Boolean).join(separador);

  const linhas = {
    cargo: juntar([a.cargo, a.oab], ' · '),
    endereco: juntar([ESC.endereco, ESC.cidade], ' — '),
    telefones: juntar([a.telefone ?? ESC.telefone, a.whatsapp ? `WhatsApp ${a.whatsapp}` : null], ' · '),
    contato: juntar([emailContato, ESC.site], ' · '),
  };

  const div = (conteudo: string, estilo = '') => (conteudo ? `<div style="${estilo}">${escaparHtml(conteudo)}</div>` : '');
  const cor = ESC.corPrincipal;
  const src = logo ? (srcLogo === 'data-url' ? `data:image/png;base64,${logo.toString('base64')}` : `cid:${CID_LOGO}`) : null;

  const html = [
    '<table cellpadding="0" cellspacing="0" border="0" style="margin-top:20px;font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#333333;line-height:1.45">',
    '<tr>',
    src
      ? `<td style="padding-right:14px;border-right:2px solid ${cor};vertical-align:middle"><img src="${src}" alt="${escaparHtml(ESC.nome)}" width="110" style="display:block;border:0"></td>`
      : '',
    `<td style="${src ? 'padding-left:14px;' : `border-left:3px solid ${cor};padding-left:10px;`}vertical-align:top">`,
    div(a.nome, `font-weight:bold;font-size:14px;color:${cor}`),
    div(linhas.cargo),
    div(ESC.nome, 'margin-top:6px;font-weight:bold'),
    div(linhas.endereco),
    div(linhas.telefones),
    div(linhas.contato),
    '</td></tr></table>',
  ].join('');

  const texto = [a.nome, linhas.cargo, ESC.nome, linhas.endereco, linhas.telefones, linhas.contato].filter(Boolean).join('\n');

  return {
    html,
    texto,
    logo: logo && srcLogo !== 'data-url' ? { nome: 'logo-dam.png', conteudo: logo, mimeType: 'image/png', cid: CID_LOGO } : null,
  };
}

// Página HTML para conferir a assinatura no navegador.
export async function previa(id: string): Promise<string> {
  const { html } = await montarAssinatura(await obter(id), 'data-url');
  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>Prévia da assinatura</title></head><body style="margin:24px;background:#fff"><p style="font-family:Arial;font-size:14px;color:#222">Prezados,<br><br>Texto do e-mail…</p>${html}</body></html>`;
}
